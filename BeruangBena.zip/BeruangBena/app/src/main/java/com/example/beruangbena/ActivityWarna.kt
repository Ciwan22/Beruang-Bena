package com.example.beruangbena

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class ActivityWarna : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_warna)

        val buttonYoutube = findViewById<ImageButton>(R.id.btn_youtube)

        buttonYoutube.setOnClickListener {
            val intent = Intent (this, ActivityGamesWarna::class.java)
            startActivity(intent)
            finish()
        }
        }


}