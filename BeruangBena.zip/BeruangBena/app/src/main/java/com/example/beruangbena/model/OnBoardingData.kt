package com.example.beruangbena.model

import android.icu.text.CaseMap

class OnBoardingData(var title: String, var desc: String , var imageUrl: Int) {

}