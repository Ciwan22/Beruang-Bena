package com.example.beruangbena

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class DashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboar_activitty)

        val buttonWarna = findViewById<ImageButton>(R.id.btn_warna)

        buttonWarna.setOnClickListener {

            val intent = Intent (this, ActivityWarna::class.java)
            startActivity(intent)
            finish()
        }

    }
}