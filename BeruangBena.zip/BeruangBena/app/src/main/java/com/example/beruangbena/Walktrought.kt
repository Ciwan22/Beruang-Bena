package com.example.beruangbena

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import androidx.viewpager.widget.ViewPager
import com.example.beruangbena.adapter.OnBoardingViewPagerAdapter
import com.example.beruangbena.model.OnBoardingData
import com.google.android.material.tabs.TabLayout
import java.nio.file.Files.size

class Walktrought : AppCompatActivity() {

    var onBoardingViewPagerAdapter: OnBoardingViewPagerAdapter? = null
    var tabLayout: TabLayout? = null
    var onBoardingViewPager: ViewPager? = null
    var next: TextView? = null
    var position= 0
    var sharedPreferences : SharedPreferences? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (restorePrefData()){

            val i = Intent(applicationContext, DashboardActivity::class.java)
            startActivity(i)
            finish()
        }

        //requestWindowFeature(Window.FEATURE_NO_TITLE)
        //this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        //supportActionBar!!.hide()
        setContentView(R.layout.activity_walktrought)

         tabLayout = findViewById(R.id.tab_indicator)
         next = findViewById(R.id.next)

        val onBoardingData:MutableList<OnBoardingData> = ArrayList()
        onBoardingData.add(OnBoardingData("Mengenal Warna", "Belajar dan Bermain Warna",R.drawable.warna))
        onBoardingData.add(OnBoardingData("Mengenal Warna Bentuk", "Belajar dan Bermain Bentuk Bangun Datar",R.drawable.kubus))
        onBoardingData.add(OnBoardingData("Mengenal Warna Angka", "Belajar dan Bermain Mengenai Angka",R.drawable.angka))
        onBoardingData.add(OnBoardingData("Mengenal Huruf", "Belajar dan Bermain Macam Macam Huruf",R.drawable.abcd))

        setOnBoardingViewPagerAdapter(onBoardingData)

        position = onBoardingViewPager!!.currentItem

        next?.setOnClickListener {

            if (position < onBoardingData.size){
                position++
                onBoardingViewPager!!.currentItem = position
            }

            if (position == onBoardingData.size){
                savePrefData()
                val i = Intent(applicationContext, DashboardActivity::class.java)
                startActivity(i)

                finish()
            }

        }
        tabLayout!!.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener{
            override fun onTabReselected(tab: TabLayout.Tab?) {
            }

            override fun onTabUnselected(p0: TabLayout.Tab?) {
            }

            override fun onTabSelected(tab: TabLayout.Tab?) {

                position = tab!!.position
                if (tab.position == onBoardingData.size -1){
                    next!!.text == "Mulai"
                }else{
                    next!!.text = "Next"
                }

            }

        })
    }

    private fun setOnBoardingViewPagerAdapter(onBoardingData: List<OnBoardingData>){
        onBoardingViewPager = findViewById(R.id.screenPager)
        onBoardingViewPagerAdapter = OnBoardingViewPagerAdapter(this, onBoardingData)
        onBoardingViewPager!!.adapter = onBoardingViewPagerAdapter
        tabLayout?.setupWithViewPager(onBoardingViewPager)

    }

    private fun savePrefData(){

        sharedPreferences = applicationContext.getSharedPreferences("Kembali", Context.MODE_PRIVATE)
        val editor: SharedPreferences.Editor = sharedPreferences!!.edit()
        editor.putBoolean("isFirstTimeRun", true)
        editor.apply()
    }

    private fun restorePrefData(): Boolean{
        sharedPreferences = applicationContext.getSharedPreferences("Kembali", Context.MODE_PRIVATE)
        return sharedPreferences!!.getBoolean("isFirstTimeRun", false)
    }

}