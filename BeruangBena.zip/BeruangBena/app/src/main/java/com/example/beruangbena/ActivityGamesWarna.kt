package com.example.beruangbena

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ActivityGamesWarna : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_games_warna)
    }
}